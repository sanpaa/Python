from distutils.core import setup

setup(
    name            = 'filmes',
    version         = '1.0.0',
    py_modules      = ['filmes'],
    author          = 'hfpython',
    author_email    = 'hfpython@firstlab.com',
    url             = 'https://www.headfirstlabs.com',
    description     = 'Uma simples impressão da lista filmes',
    
)